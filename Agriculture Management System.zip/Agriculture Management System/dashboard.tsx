"use client"

import { useState } from 'react'
import { MapContainer, TileLayer, Polygon } from 'react-leaflet'
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown, Droplets, Plant, Sun } from 'lucide-react'

// Simulated data
const fieldData = [
  { name: 'قطعه 1', area: 100, moisture: 60, health: 80 },
  { name: 'قطعه 2', area: 150, moisture: 55, health: 75 },
  { name: 'قطعه 3', area: 120, moisture: 65, health: 85 },
]

const moistureData = [
  { name: 'فروردین', moisture: 45 },
  { name: 'اردیبهشت', moisture: 50 },
  { name: 'خرداد', moisture: 55 },
  { name: 'تیر', moisture: 60 },
  { name: 'مرداد', moisture: 58 },
  { name: 'شهریور', moisture: 52 },
]

export default function Dashboard() {
  const [selectedField, setSelectedField] = useState(fieldData[0])

  return (
    <div className="flex flex-col p-4 space-y-4 bg-background text-foreground">
      <h1 className="text-2xl font-bold">داشبورد مدیریت کشاورزی</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>نقشه مزرعه</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <MapContainer center={[32.6539, 51.6660]} zoom={13} style={{ height: '100%', width: '100%' }}>
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              {/* Here you would add Polygon components for each field */}
            </MapContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>وضعیت رطوبت خاک</CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={moistureData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="moisture" stroke="#8884d8" fill="#8884d8" />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="water">
        <TabsList>
          <TabsTrigger value="water">مدیریت آب</TabsTrigger>
          <TabsTrigger value="crop">نظارت بر محصول</TabsTrigger>
          <TabsTrigger value="planning">برنامه‌ریزی کشت</TabsTrigger>
        </TabsList>
        <TabsContent value="water">
          <Card>
            <CardHeader>
              <CardTitle>مدیریت منابع آب</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Droplets className="h-8 w-8 text-blue-500" />
                <div>
                  <p className="text-lg font-semibold">رطوبت خاک فعلی: {selectedField.moisture}%</p>
                  <p>وضعیت آبیاری: نیاز به آبیاری در 2 روز آینده</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="crop">
          <Card>
            <CardHeader>
              <CardTitle>وضعیت محصول</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Plant className="h-8 w-8 text-green-500" />
                <div>
                  <p className="text-lg font-semibold">سلامت محصول: {selectedField.health}%</p>
                  <p>وضعیت رشد: مطلوب</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="planning">
          <Card>
            <CardHeader>
              <CardTitle>برنامه‌ریزی کشت</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Sun className="h-8 w-8 text-yellow-500" />
                <div>
                  <p className="text-lg font-semibold">محصول فعلی: نیشکر</p>
                  <p>زمان برداشت تخمینی: 3 ماه دیگر</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>انتخاب قطعه زمین</CardTitle>
        </CardHeader>
        <CardContent>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                {selectedField.name}
                <ChevronDown className="ml-2 h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              {fieldData.map((field) => (
                <DropdownMenuItem key={field.name} onSelect={() => setSelectedField(field)}>
                  {field.name}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </CardContent>
      </Card>
    </div>
  )
}